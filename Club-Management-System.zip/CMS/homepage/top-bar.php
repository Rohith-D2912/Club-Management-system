<div class="club_welcome">Welcome to <?php echo '<span>'.$_SESSION['clubname'].'</span>';?></div>


<style type="text/css">
	
	.club_welcome{

		background-color: #D6D6D7;
		color: #4d4d4d;
		text-align: center;
	}

	.club_welcome span{
		font-weight: bold;
	}

</style>